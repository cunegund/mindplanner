//
//  Mindplanner2.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

//import Foundation
//import SwiftUI
//
//struct Mindplanner2 {
//    private var imageName: String
//    var image: Image {
//        Image(imageName)
//    }
//    
//}
