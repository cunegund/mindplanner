//
//  ContentViewModel.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 23/01/2024.
//

import Foundation
import SwiftUI

extension ContentView {
    class ViewModel: ObservableObject {
        @AppStorage("AUTH_KEY") var authenticated = false {
            willSet {objectWillChange.send ()}
        }
        @AppStorage ("USER_KEY") var username = ""
        @Published var password = ""
        @Published var name = ""
        @Published var invalid: Bool = false
        
        private var sampleUser = "username"
        private var samplePassword = "password"
        private var sampleName = "name"
        
        init(){
            print ("Currently logged on: \(authenticated)")
            print ("Current user: \(username)")
        }
        
        func toggleAuthentication() {
            self.password = ""
            withAnimation {
                authenticated.toggle()
            }
        }
        
        func authenticate() {
            guard self.username.lowercased() == sampleUser
            else{
                self.invalid = true
                return
            }
            guard self.password.lowercased() == password
            else{
                self.invalid = true
                return
            }
            guard self.name.lowercased() == name
            else{
                self.invalid = true
                return
            }
            toggleAuthentication()
        }
        func logOut() {
            toggleAuthentication()
        }
        func logPressed() {
            print("Button pressed")
        }
    }
}

extension LogInSheetView {
    class ViewModel: ObservableObject {
        @AppStorage("AUTH_KEY") var authenticated = false {
            willSet {objectWillChange.send ()}
        }
        @AppStorage ("USER_KEY") var username = ""
        @Published var password = ""
        @Published var name = ""
        @Published var invalid: Bool = false
        
        private var sampleUser = "username"
        private var samplePassword = "password"
        private var sampleName = "name"
        
        init(){
            print ("Currently logged on: \(authenticated)")
            print ("Current user: \(username)")
        }
        
        func toggleAuthentication() {
            self.password = ""
            withAnimation {
                authenticated.toggle()
            }
        }
        
        func authenticate() {
            guard self.username.lowercased() == sampleUser
            else{
                self.invalid = true
                return
            }
            guard self.password.lowercased() == password
            else{
                self.invalid = true
                return
            }
            guard self.name.lowercased() == name
            else{
                self.invalid = true
                return
            }
            toggleAuthentication()
        }
        func logOut() {
            toggleAuthentication()
        }
        func logPressed() {
            print("Button pressed")
        }
    }
}

extension LogOutView {
    class ViewModel: ObservableObject {
        @AppStorage("AUTH_KEY") var authenticated = false {
            willSet {objectWillChange.send ()}
        }
        @AppStorage ("USER_KEY") var username = ""
        @Published var password = ""
        @Published var name = ""
        @Published var invalid: Bool = false
        
        private var sampleUser = "username"
        private var samplePassword = "password"
        private var sampleName = "name"
        
        init(){
            print ("Currently logged on: \(authenticated)")
            print ("Current user: \(username)")
        }
        
        func toggleAuthentication() {
            self.password = ""
            withAnimation {
                authenticated.toggle()
            }
        }
        
        func authenticate() {
            guard self.username.lowercased() == sampleUser
            else{
                self.invalid = true
                return
            }
            guard self.password.lowercased() == password
            else{
                self.invalid = true
                return
            }
            guard self.name.lowercased() == name
            else{
                self.invalid = true
                return
            }
            toggleAuthentication()
        }
        func logOut() {
            toggleAuthentication()
        }
        func logPressed() {
            print("Button pressed")
        }
    }
}

extension CreateAccView{
    class ViewModel: ObservableObject {
        @AppStorage("AUTH_KEY") var authenticated = false {
            willSet {objectWillChange.send ()}
        }
        @AppStorage ("USER_KEY") var username = ""
        @Published var password = ""
        @Published var name = ""
        @Published var invalid: Bool = false
        
        private var sampleUser = "username"
        private var samplePassword = "password"
        private var sampleName = "name"
        
        init(){
            print ("Currently logged on: \(authenticated)")
            print ("Current user: \(username)")
        }
        
        func toggleAuthentication() {
            self.password = ""
            withAnimation {
                authenticated.toggle()
            }
        }
        
        func authenticate() {
            guard self.username.lowercased() == sampleUser
            else{
                self.invalid = true
                return
            }
            guard self.password.lowercased() == password
            else{
                self.invalid = true
                return
            }
            guard self.name.lowercased() == name
            else{
                self.invalid = true
                return
            }
            toggleAuthentication()
        }
        func logOut() {
            toggleAuthentication()
        }
        func logPressed() {
            print("Button pressed")
        }
    }
}
