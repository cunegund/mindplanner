//
//  HeaderView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 24/01/2024.
//

import SwiftUI

struct HeaderView: View {
    @State private var isShowingAnotherView = false

    var body: some View {
        NavigationView {
            ZStack {
                Rectangle()
                    .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .ignoresSafeArea()
                HStack(spacing: 90) {
                    NavigationLink(destination: LogOutView(), isActive: $isShowingAnotherView) {
                        Ellipse()
                            .foregroundColor(Color(red: 0.49, green: 0.63, blue: 0.18))
                            .frame(width: 45, height: 45)
                    }

                    Text("Hi, Name!")
                        .font(Font.custom("FilsonSoftRegular", size: 17))
                        .lineSpacing(22)
                        .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                    
                    Image(systemName: "line.3.horizontal")
                        .font(.system(size: 36))
                        .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                }
            }
        }
    }
}

#Preview {
    HeaderView()
}
