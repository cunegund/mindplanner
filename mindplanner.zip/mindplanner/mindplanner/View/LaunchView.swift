//
//  LaunchView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 30/01/2024.
//
import SwiftUI

class NavigationHelper: ObservableObject {
    @Published var isActive: Bool = false
}

struct LaunchView: View {
    var image1: Image
    var image2: Image
    @State private var image1Offset: CGFloat = 0
    @State private var image2Offset: CGFloat = 0
    @StateObject private var navigationHelper = NavigationHelper()
    
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                .ignoresSafeArea()
            
            VStack {
                if !navigationHelper.isActive {
                    image1
                        .offset(y: image1Offset)
                        .opacity(navigationHelper.isActive ? 0 : 1)
                        .scaleEffect(navigationHelper.isActive ? 0.5 : 1)
                        .onAppear {
                            withAnimation(Animation.easeInOut(duration: 1.5).delay(2.0)) {
                                self.image1Offset = -UIScreen.main.bounds.height / 2.7
                            }
                        }
                    
                    image2
                        .offset(y: image2Offset)
                        .opacity(navigationHelper.isActive ? 0 : 1)
                        .scaleEffect(navigationHelper.isActive ? 0.5 : 1)
                        .onAppear {
                            withAnimation(Animation.easeInOut(duration: 1.5).delay(2.0)) {
                                self.image2Offset = UIScreen.main.bounds.height / 2
                            }
                        }
                }
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
                    withAnimation {
                        self.navigationHelper.isActive = true
                    }
                }
            }
        }
        .background(
            NavigationLink(
                destination: ContentView(),
                isActive: $navigationHelper.isActive,
                label: { EmptyView() }
            )
            .opacity(0)
            .frame(width: 0, height: 0)
        )
    }
}


struct LaunchView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchView(image1: Image("logo"), image2: Image("logotype"))
    }
}

#Preview {
    LaunchView(image1: Image("logo"), image2: Image("logotype"))
}
