//
//  MindfulnessView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

import SwiftUI

struct MindfulnessView: View {
    let image = Image("mindfulnessImage")

    
    var body: some View {
        ZStack(){
            Rectangle()
                      .foregroundColor(.clear)
                      .frame(width: 361, height: 337)
                      .background(Color(red: 0.33, green: 0.47, blue: 0.01))
                      .cornerRadius(25)
                      .offset(x: 0, y: 22.50)
                      .shadow(
                        color: Color(red: 0.33, green: 0.47, blue: 0.01, opacity: 0.88), radius: 2
                      )
                    Text("Mindfulness")
                      .font(.custom("FilsonSoftBook", size: 28))
                      .lineSpacing(34)
                      .underline()
                      .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                      .offset(x: -85.50, y: -172)
            image

//                    Text()
//                .font(.subheadline)
//                      .lineSpacing(22)
//                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
//                      .offset(x: -164, y: 20)
//                    Text("􀯻")
//                      .lineSpacing(22)
//                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
//                      .offset(x: 160, y: 20)
                    Text("RECOMMENDED")
                      .font(.custom("FilsonSoftBook", size: 16))
                      .lineSpacing(21)
                      .foregroundColor(Color(red: 0.84, green: 0.90, blue: 0.70))
                      .offset(x: -0.50, y: -116.50)
            ZStack(){
                       Text("Go to program")
                         .font(.custom("FilsonSoftBook", size: 17))
                         .lineSpacing(22)
                         .underline()
                         .foregroundColor(Color(red: 0.84, green: 0.90, blue: 0.70))
                         .offset(x: 0, y: 153)
            }
        }
    }
}

#Preview {
    MindfulnessView()
}
