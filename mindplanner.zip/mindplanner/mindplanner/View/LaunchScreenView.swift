//
//  LaunchScreenView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 26/01/2024.
//

import SwiftUI

struct LaunchScreenView: View {
    var image1: Image
    var image2: Image
    @State private var image1Offset: CGFloat = 0
    @State private var image2Offset: CGFloat = 0
    @State private var isActive = false
    

    var body: some View {
        NavigationView {
                    ZStack {
                        Rectangle()
                            .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                            .ignoresSafeArea()
                        
                        VStack {
                            if !isActive {
                                image1
                                    .offset(y: image1Offset)
                                    .opacity(isActive ? 0 : 1)
                                    .scaleEffect(isActive ? 0.5 : 1)
                                    .onAppear {
                                        withAnimation(Animation.easeInOut(duration: 1.5).delay(2.0)) {
                                            self.image1Offset = -UIScreen.main.bounds.height / 2.7
                                        }
                                    }
                                
                                image2
                                    .offset(y: image2Offset)
                                    .opacity(isActive ? 0 : 1)
                                    .scaleEffect(isActive ? 0.5 : 1)
                                    .onAppear {
                                        withAnimation(Animation.easeInOut(duration: 1.5).delay(2.0)) {
                                            self.image2Offset = UIScreen.main.bounds.height / 2
                                        }
                                    }
                            }
                        }
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
                                withAnimation {
                                    self.isActive = true
                                }
                            }
                        }
                    }
                    .background(
                        NavigationLink(
                            destination: CreateAccView(),
                            isActive: $isActive,
                            label: { EmptyView() }
                            
                )
            )
                    
        }
    }
}


#Preview {
    LaunchScreenView(image1: Image("logo"),
    image2: Image("logotype"))
}
