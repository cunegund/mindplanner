//
//  loginView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

import SwiftUI

struct loginView: View {
    @StateObject var vm = ViewModel()
    @State private var isShowingAnotherView = false
    @State private var screenOffset: CGFloat = 0
    
    var body: some View {
        NavigationView{
            ZStack(){
                HStack(spacing: 10){
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 361, height: 723)
                        .background(Color(red: 0.09, green: 0.10, blue: 0.06))
                        .cornerRadius(25)
                }
                .padding(EdgeInsets(top: 10, leading: 16, bottom: 10, trailing: 16))
                .frame(width: 382.30, height: 743)
                .offset(x: -0.35, y: 14.50)
                HStack(spacing: 10){
                    Button("Forgot your password? Click here", action: vm.logPressed)
                        .font(Font.custom("Filson Soft", size: 15))
                        .underline()
                        .lineSpacing(20)
                        .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                }
                .padding(EdgeInsets(top: 24, leading: 32, bottom: 10, trailing: 32))
                .frame(width: 382.30, height: 36)
                .offset(x: -0.35, y: -14)
                HStack(){
                    Text("Log into your account")
                        .font(Font.custom("Filson Soft", size: 22))
                        .lineSpacing(28)
                        .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                }
                .padding(EdgeInsets(top: 16, leading: 32, bottom: 16, trailing: 32))
                .frame(width: 382.30, height: 66)
                .offset(x: -0.35, y: -284)
                NavigationLink(destination: CreateAccView(), isActive: $isShowingAnotherView) {
                    VStack(alignment: .leading, spacing: 10) {
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 86, height: 3)
                            .background(Color(red: 0.71, green: 0.82, blue: 0.46))
                            .cornerRadius(100)
                            .rotationEffect(.degrees(-180))
                            .onTapGesture {
                                withAnimation(Animation.easeInOut(duration: 1.5).delay(2.0)) {
                                    self.screenOffset = UIScreen.main.bounds.height / 2
                                }
                            }
                    }
                }
                            .padding(10)
                            .frame(width: 103.11, height: 23)
                            .offset(x: 0.06, y: -334.50)
                VStack(spacing: 26) {
                    Text("Or log in with:")
                        .font(Font.custom("Filson Soft", size: 17))
                        .lineSpacing(22)
                        .foregroundColor(Color(red: 0.84, green: 0.90, blue: 0.70))
                    HStack(spacing: 23) {
                        Text("Continue with Apple")
                            .font(Font.custom("Filson Soft", size: 20))
                            .lineSpacing(25)
                            .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                    }
                    .padding(EdgeInsets(top: 6, leading: 27, bottom: 6, trailing: 30))
                    .frame(width: 314, height: 42)
                    .background(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .cornerRadius(28)
                    HStack(spacing: 20) {
                        Text("Continue with Google")
                            .font(Font.custom("Filson Soft", size: 20))
                            .lineSpacing(25)
                            .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                    }
                    .padding(EdgeInsets(top: 7, leading: 33, bottom: 7, trailing: 33))
                    .frame(width: 314, height: 41)
                    .background(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .cornerRadius(28)
                }
                .padding(EdgeInsets(top: 32, leading: 16, bottom: 64, trailing: 16))
                .offset(x: -0.50, y: 230.50)
                ZStack() {
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 314, height: 52)
                        .background(Color(red: 0.33, green: 0.47, blue: 0.01))
                        .cornerRadius(26)
                        .offset(x: 0, y: 0)
                    Button("Log in", action: vm.authenticate)
                        .font(Font.custom("Filson Soft", size: 20))
                        .lineSpacing(25)
                        .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                        .offset(x: -1, y: 1.50)
                }
                .frame(width: 314, height: 52)
                .offset(x: 0.50, y: 66)
                .shadow(
                    color: Color(red: 0.33, green: 0.47, blue: 0.01, opacity: 0.10), radius: 3
                )
                ZStack() {
                    HStack(spacing: 5) {
                        TextField("Type here", text: $vm.username)
                            .font(Font.custom("Filson Soft", size: 17))
                            .multilineTextAlignment(.leading)
                            .keyboardType(.default)
                            .lineSpacing(22)
                            .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06).opacity(0.70))
                    }
                    .padding(EdgeInsets(top: 11, leading: 27, bottom: 11, trailing: 27))
                    .frame(width: 314, height: 52)
                    .background(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .cornerRadius(29.50)
                    .offset(x: 0, y: 15.50)
                    Text("E-mail")
                        .font(Font.custom("Filson Soft", size: 17))
                        .lineSpacing(22)
                        .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95).opacity(0.70))
                        .offset(x: -110, y: -30.50)
                }
                .frame(width: 314, height: 83)
                .offset(x: 1.50, y: -189.50)
                ZStack() {
                    HStack(spacing: 5) {
                        SecureField("Type here", text: $vm.password)
                            .keyboardType(.default)
                            .font(Font.custom("Filson Soft", size: 17))
                            .lineSpacing(22)
                            .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06).opacity(0.70))
                            .privacySensitive()
                    }
                    .padding(EdgeInsets(top: 11, leading: 27, bottom: 11, trailing: 27))
                    .frame(width: 314, height: 52)
                    .background(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .cornerRadius(29.50)
                    .offset(x: 0, y: 15.50)
                    Text("Password")
                        .font(Font.custom("Filson Soft", size: 17))
                        .lineSpacing(22)
                        .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95).opacity(0.70))
                        .offset(x: -100, y: -30.50)
                }
                .navigationBarTitle("")
                .navigationBarHidden(true)
                .navigationBarBackButtonHidden(true)
                .frame(width: 314, height: 83)
                .offset(x: 1.50, y: -85.50)
            }
            
            .frame(width: 393, height: 714);
        }
    }
}

#Preview {
    loginView()
}
