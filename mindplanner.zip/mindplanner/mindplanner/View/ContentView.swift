//
//  ContentView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @StateObject var vm = ViewModel()
    
    var body: some View {
        if vm.authenticated {
            ZStack{
                Rectangle()
                    .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .ignoresSafeArea()
                VStack{
                    HeaderView()
                       .offset(y:-50)
                    Spacer()
                        .frame(height: 10)
                    CalendarView()
                        .padding(10)
                    MindfulnessView()
                }
                .padding(16)
                .navigationBarTitle("")
                .navigationBarHidden(true)
                .navigationBarBackButtonHidden(true)
            }
        }
        else{
            ZStack(){
                loginView()
                    .offset( y: 60)
            }
            .transition(/*@START_MENU_TOKEN@*/.identity/*@END_MENU_TOKEN@*/)
            }
        }
    }


#Preview {
    ContentView()
}
