//
//  LogOut.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 29/01/2024.
//

import SwiftUI

struct LogOutView: View {
    @StateObject var vm = ViewModel()

    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                .ignoresSafeArea()
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 150, height: 30)
              .background(Color(red: 0.33, green: 0.47, blue: 0.01))
              .cornerRadius(26)
              .offset(x: 0, y: 0)
            Button("Log out", action: vm.logOut)
                .font(Font.custom("Filson Soft", size: 20))
                .lineSpacing(25)
                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
            
        }
    }
}

#Preview {
    LogOutView()
}
