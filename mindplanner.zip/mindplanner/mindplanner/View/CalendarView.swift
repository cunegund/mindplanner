//
//  CalendarView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 23/01/2024.
//

import SwiftUI
import SwiftData

struct CalendarView: View {
    var body: some View {
        ZStack(){
            Text("Calendar")
                .font(.custom("FilsonSoftBook", size: 28))
                .lineSpacing(34)
                .underline()
                .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                .offset(x: -96, y: -146)
            Rectangle()
                .foregroundColor(.clear)
                .frame(width: 361, height: 227)
                .background(Color(red: 0.09, green: 0.10, blue: 0.06))
                .cornerRadius(25)
                .offset(x: 0, y: -7.50)
                .shadow(color: Color(red: 0.09, green: 0.10, blue: 0.06, opacity: 0.56), radius: 2
                          )
            
                    Text("8:30")
                      .font(.custom("FilsonSoftBook", size: 13))
                      .lineSpacing(8)
                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                      .offset(x: -150.50, y: -90)
                    Text("Work")
                      .font(.custom("FilsonSoftBook", size: 20))
                      .lineSpacing(25)
                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                      .offset(x: -100, y: -87.50)
                    Text("Note: Office today\nLocation : 3529 Settlers Lane,\nHuntington, NY")
                      .font(.custom("FilsonSoftBook", size: 13))
                      .lineSpacing(6)
                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95).opacity(0.60))
                      .offset(x: -32, y: -44)
                    Text("19:00")
                      .font(.custom("FilsonSoftBook", size: 13))
                      .lineSpacing(18)
                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                      .offset(x: -150, y: 8)
                    Text("Meeting")
                      .font(.custom("FilsonSoftBook", size: 20))
                      .lineSpacing(25)
                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                      .offset(x: -83, y: 10.50)
                    Text("Note: Dinner with Joe and Anne\nLocation: Balthazar, 80 Spring St, NY")
                      .font(.custom("FilsonSoftBook", size: 13))
                      .lineSpacing(6)
                      .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95).opacity(0.60))
                      .offset(x: -9, y: 43)
            ZStack(){
                Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 32, height: 57)
                            .cornerRadius(16)
                            .overlay(
                              RoundedRectangle(cornerRadius: 16)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.49, green: 0.63, blue: 0.18), lineWidth: 0.50)
                            )
                            .offset(x: 0, y: 0)
                          Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 24, height: 49.88)
                            .cornerRadius(12)
                            .overlay(
                              RoundedRectangle(cornerRadius: 12)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.33, green: 0.47, blue: 0.01), lineWidth: 0.50)
                            )
                            .offset(x: 0, y: 0)
                          Ellipse()
                            .foregroundColor(Color(red: 0.83, green: 0.95, blue: 0.54).opacity(0.70))
                            .frame(width: 24, height: 24)
                            .overlay(
                              Ellipse()
                                .inset(by: 0.50)
                                .stroke(
                                  Color(red: 0.83, green: 0.95, blue: 0.54).opacity(0.50), lineWidth: 0.50
                                )
                            )
                            .offset(x: 0, y: -12.94)
            }
            .frame(width: 32, height: 57)
            .offset(x: 147.50, y: 28.50)
            ZStack(){
                Rectangle()
                           .foregroundColor(.clear)
                           .frame(width: 32, height: 57)
                           .cornerRadius(16)
                           .overlay(
                RoundedRectangle(cornerRadius: 16)
                               .inset(by: 0.50)
                               .stroke(Color(red: 0.49, green: 0.63, blue: 0.18), lineWidth: 0.50)
                           )
                           .offset(x: 0, y: 0)
                         Rectangle()
                           .foregroundColor(.clear)
                           .frame(width: 24, height: 49.88)
                           .cornerRadius(12)
                           .overlay(
                        RoundedRectangle(cornerRadius: 12)
                               .inset(by: 0.50)
                               .stroke(Color(red: 0.33, green: 0.47, blue: 0.01), lineWidth: 0.50)
                           )
                           .offset(x: 0, y: 0)
                         Ellipse()
                           .foregroundColor(Color(red: 0.83, green: 0.95, blue: 0.54).opacity(0.70))
                           .frame(width: 24, height: 24)
                           .overlay(
                             Ellipse()
                               .inset(by: 0.50)
                               .stroke(
                                 Color(red: 0.83, green: 0.95, blue: 0.54).opacity(0.50), lineWidth: 0.50
                               )
                           )
                           .offset(x: 0, y: -12.94)
            }
            .frame(width: 32, height: 57)
            .offset(x: 147.50, y: -68.50)
        }
        .frame(width: 361, height: 242);
    }
}


#Preview {
    CalendarView()
}
