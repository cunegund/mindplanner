//
//  TestView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 29/01/2024.
//

import SwiftUI

struct TestView: View {
    var body: some View {
        HStack(spacing: 90){
                Ellipse()
                .foregroundColor(Color(red: 0.49, green: 0.63, blue: 0.18))
                .frame(width: 45, height: 45)
                       
                  Text("Hi, Name!")
                    .font(Font.custom("FilsonSoftRegular", size: 17))
                    .lineSpacing(22)
                    .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                  Text("Settings")
                    .font(Font.custom("FilsonSoftBook", size: 12))
                    .lineSpacing(22)
                    .foregroundColor(.black)

        }
        .padding(16)
    }
}

#Preview {
    TestView()
}
