//
//  mindfulnessImage.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

import SwiftUI

struct mindfulnessImage: View {
    var image: Image
    
    var body: some View {
        image
            }
    }


#Preview {
    mindfulnessImage(image: Image("mindfulnessImage"))
}
