//
//  ContentView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @StateObject var vm = ViewModel()
    
    var body: some View {
        if vm.authenticated {
            ZStack{
                Rectangle()
                    .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                    .ignoresSafeArea()
                VStack{
                    HeaderView()
                       .offset(y:-30)
                    Spacer()
                        .frame(height: 10)
                    CalendarView()
                        .foregroundColor(.clear)
                        .padding(5)
                    MindfulnessView()
                }
                .padding(16)
                .navigationBarTitle("")
                .navigationBarHidden(true)
                .navigationBarBackButtonHidden(true)
            }
        }
        else{
            ZStack(){
                CreateAccView()
            }
            .navigationBarTitle("")
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
            .transition(/*@START_MENU_TOKEN@*/.identity/*@END_MENU_TOKEN@*/)
            }
        }
    }


#Preview {
    ContentView()
}
