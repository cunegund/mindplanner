//
//  CreateAccView.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 30/01/2024.
//

import SwiftUI

struct CreateAccView: View {
    let image = Image("googleLogo")
    @State var showingLogInSheet = false
    @StateObject var vm = ViewModel()
    
    var body: some View {
        if !vm.authenticated {
                ZStack{
                    Rectangle()
                        .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                        .ignoresSafeArea()
                    VStack(spacing: 24){
                        HStack(spacing: 10) {
                            Text("Create your account")
                                .font(Font.custom("FilsonSoftBook", size: 22))
                                .lineSpacing(28)
                                .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                        }
                        .offset(y:-50)
                        .padding(EdgeInsets(top: 16, leading: 32, bottom: 16, trailing: 32))
                        .frame(width: 393, height: 51);
                        HStack(spacing: 23){
                            Image(systemName: "envelope")
                                .font(Font.custom("SF Pro", size: 20))
                                .lineSpacing(20)
                                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                            Text("Continue with E-mail")
                                .font(Font.custom("Filson Soft", size: 20))
                                .lineSpacing(25)
                                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                        }
                        .padding(EdgeInsets(top: 7, leading: 28, bottom: 7, trailing: 33))
                        .frame(width: 356, height: 42)
                        .background(Color(red: 0.09, green: 0.10, blue: 0.06))
                        .cornerRadius(28)
                        .offset(y:-50)
                        HStack(spacing: 23) {
                            Image(systemName: "apple.logo")
                                .font(.system(size: 26))
                                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                                .offset(x:-5)
                            Text("Continue with Apple")
                                .font(Font.custom("Filson Soft", size: 20))
                                .lineSpacing(25)
                                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                        }
                        .padding(EdgeInsets(top: 6, leading: 27, bottom: 6, trailing: 30))
                        .frame(width: 355, height: 42)
                        .background(Color(red: 0.09, green: 0.10, blue: 0.06))
                        .cornerRadius(28)
                        .offset(y:-50)
                        HStack(spacing: 20) {
                            image
                            Text("Continue with Google")
                                .font(Font.custom("Filson Soft", size: 20))
                                .lineSpacing(25)
                                .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                        }
                        .padding(EdgeInsets(top: 7, leading: 33, bottom: 7, trailing: 33))
                        .frame(width: 354, height: 42)
                        .background(Color(red: 0.09, green: 0.10, blue: 0.06))
                        .cornerRadius(28)
                        .offset(y:-50)
                    }
                    .padding(16)
                    .frame(width: 393, height: 206);
                    HStack(spacing: 10) {
                        Text("By tapping Continue, you accept our Terms and our Privacy Policy")
                            .font(Font.custom("FilsonSoftBook", size: 15))
                            .multilineTextAlignment(.center)
                            .lineSpacing(10)
                            .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06).opacity(0.70))
                    }
                    .offset(y:130)
                    .padding(10)
                    .frame(width: 300, height: 100);
                    HStack(spacing: 13) {
                        Text("Already have an account?")
                            .font(Font.custom("FilsonSoftBook", size: 17))
                            .lineSpacing(6)
                            .foregroundColor(Color(red: 0.09, green: 0.10, blue: 0.06))
                        
                            HStack(spacing: 20) {
                                Button("Log in"){
                                    showingLogInSheet.toggle()
                                }
                                    .font(Font.custom("FilsonSoftBook", size: 17))
                                    .lineSpacing(2)
                                    .foregroundColor(Color(red: 0.96, green: 0.98, blue: 0.95))
                            }
                        .padding(EdgeInsets(top: 7, leading: 33, bottom: 7, trailing: 33))
                        .frame(width: 115, height: 41)
                        .background(Color(red: 0.09, green: 0.10, blue: 0.06))
                        .cornerRadius(28)
                        .overlay(
                            RoundedRectangle(cornerRadius: 28)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.09, green: 0.10, blue: 0.06), lineWidth: 0.50)
                        )
                        .sheet(isPresented: $showingLogInSheet, content: {
                            LogInSheetView()
                                .presentationDetents([.height(714)])
                        })
                    }
                    .padding(EdgeInsets(top: 16, leading: 16, bottom: 16, trailing: 16))
                    .frame(width: 393)
                    .offset(x: 0, y: 350)
                }
        } 
    else{
            ContentView()
        }
        }
    }

#Preview {
    CreateAccView()
}
