//
//  mindplanner2App.swift
//  mindplanner2
//
//  Created by Kinga Witkowska on 28/01/2024.
//

import SwiftUI
import SwiftData

@main
struct mindplanner2App: App {
    var body: some Scene {
        WindowGroup {
            LaunchScreenView(image1: Image("logo"),
                             image2: Image("logotype"))
        }
    }
}
